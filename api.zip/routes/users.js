var express = require('express');
let models = require('../models');
var router = express.Router();

/* GET all users listing. */
router.get('/', function(req, res, next) {
	models.User_Master.findAll({
		attributes: ['username']
	}).then(users=>{
		return res.status(200).json(users);
	})
});

/* POST login users id and username. */
router.post('/login', function(req, res, next) {
	models.User_Master.findOne({
		where: { 'username': req.body.username, 'password': req.body.password},
		attributes: ['username', 'id']
	}).then(users=>{
		if(users){
			return res.status(200).json(users);
		}else{
			return res.status(400).json({
				success: false,
				error: 'Error No User Found!'
			});
		}
	}).catch(error=>{
		return res.status(400).json({
			success: false,
			error: error
		});
	})
});

/* POST register password and username. */
router.post('/register', function(req, res, next) {
	models.User_Master.findOrCreate({
		where: { 'username': req.body.username, 'password': req.body.password},
		defaults: { 'username': req.body.username, 'password': req.body.password}
	}).then(user=>{
		if(user){
			return res.status(200).json({success: true, user: user});
		}else{
			return res.status(400).json({
				success: false,
				error: 'Error No User Found!'
			});
		}
	}).catch(error=>{
		return res.status(400).json({
			success: false,
			error: error
		});
	})
});


module.exports = router;
