'use strict';
module.exports = function(sequelize, DataTypes) {
  let User_Master = sequelize.define('User_Master', {
	  	id: {
	        allowNull: false,
	        autoIncrement: true,
	        primaryKey: true,
	        type: DataTypes.INTEGER
	    },
	      username: {
	        type: DataTypes.STRING
	    },
	      password: {
	        type: DataTypes.STRING
	    },
	      createdAt: {
	        allowNull: false,
	        type: DataTypes.DATE
	    },
	      updatedAt: {
	        allowNull: false,
	        type: DataTypes.DATE
	    }
  }, {
    classMethods: {
      associate: models => {
        // associations can be defined here
      }
    }
  });
  return User_Master;
};